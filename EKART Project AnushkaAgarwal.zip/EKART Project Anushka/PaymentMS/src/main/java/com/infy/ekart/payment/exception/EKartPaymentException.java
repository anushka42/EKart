package com.infy.ekart.payment.exception;

public class EKartPaymentException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EKartPaymentException(String message) {
		super(message);
	}

}
