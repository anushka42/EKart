package com.infy.ekart.seller.dto;

public enum OrderStatus {
	 PLACED, CONFIRMED, CANCELLED
}
