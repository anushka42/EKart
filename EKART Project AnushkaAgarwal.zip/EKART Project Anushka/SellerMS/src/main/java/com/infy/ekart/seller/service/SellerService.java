package com.infy.ekart.seller.service;

import com.infy.ekart.seller.dto.SellerDTO;
import com.infy.ekart.seller.exception.EKartSellerException;

public interface SellerService {

	SellerDTO authenticateSeller(String emailId, String password) throws EKartSellerException;

	String registerNewSeller(SellerDTO sellerDTO) throws EKartSellerException;
    
	void updateShippingAddress(String customerEmailId , String address) throws EKartSellerException;

	void deleteShippingAddress(String customerEmailId) throws EKartSellerException;
	
	SellerDTO getSellerByEmailId(String emailId) throws EKartSellerException;
	
}
