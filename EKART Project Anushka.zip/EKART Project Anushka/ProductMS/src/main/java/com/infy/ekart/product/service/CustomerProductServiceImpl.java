package com.infy.ekart.product.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.infy.ekart.product.dto.ProductDTO;
import com.infy.ekart.product.entity.Product;
import com.infy.ekart.product.exception.EKartProductException;
import com.infy.ekart.product.repository.ProductRepository;




//Add the missing annotations
@CrossOrigin
@Validated
@Transactional
@Service(value = "customerProductService")
public class CustomerProductServiceImpl implements CustomerProductService {
	@Autowired
	private ProductRepository productRepository;


	//This method is used to retrieve the list of all the products from database
	//Invoke appropriate method of ProductRepository, to fetch product details
	//which in turn returns a list.
	//for each product found, create and populate the ProductDTO object and add 
	//it to a List<ProductDTO>.
	//Return the above obtained list
	@Override
	public List<ProductDTO> getAllProducts() throws EKartProductException {
		
		Iterable<Product> products = productRepository.findAll();
		List<ProductDTO> productDTOs = new ArrayList<>();
		products.forEach(product -> {
			ProductDTO productDto = new ProductDTO();
			productDto.setProductId(product.getProductId());
			productDto.setName(product.getName());
			productDto.setBrand(product.getBrand());
			productDto.setCategory(product.getCategory());
			productDto.setDescription(product.getDescription());
			productDto.setPrice(product.getPrice());
			productDto.setAvailableQuantity(product.getAvailableQuantity());
			
			
			productDTOs.add(productDto);
		});
		
		return productDTOs;
	}

	//This method is used to fetch Product details of the product with the given productId
	//Invoke appropriate method of ProductRepository which will retrieve the product
	//details using the given productId (available in ProductDTO). 
	//If product exists for the given productId return the product details
	//Else, If productId does not exist, then throw an object of EKartProductException with 
	//message “ProductService.PRODUCT_NOT_AVAILABLE”
	@Override
	public ProductDTO getProductById(Integer productId) throws EKartProductException {
		
		Optional<Product> optional = productRepository.findById(productId);
		Product product = optional.orElseThrow(() -> new EKartProductException("ProductService.PRODUCT_NOT_AVAILABLE"));
		ProductDTO productDto = new ProductDTO();
		productDto.setProductId(product.getProductId());
		productDto.setName(product.getName());
		productDto.setBrand(product.getBrand());
		productDto.setCategory(product.getCategory());
		productDto.setDescription(product.getDescription());
		productDto.setPrice(product.getPrice());
		productDto.setAvailableQuantity(product.getAvailableQuantity());
		return productDto;
		
	}
	
	// This method is used to reduce the available quantity of product 
	// Invoke appropriate methods of ProductRepository to retrieve the product 
	// details using the given productId 
	// If product does not exist, then throw an object of EkartProductException 
	// with message “ProductService.PRODUCT_NOT_AVAILABLE”
	// Else, reduce the quantity of the retrieved product with the given number of quantity
	@Override
	public void reduceAvailableQuantity(Integer productId, Integer quantity) throws EKartProductException {
		Optional<Product> optional = productRepository.findById(productId);
		Product product = optional.orElseThrow(() -> new EKartProductException("ProductService.PRODUCT_NOT_AVAILABLE"));
		product.setAvailableQuantity(product.getAvailableQuantity()-quantity);
	}
}
