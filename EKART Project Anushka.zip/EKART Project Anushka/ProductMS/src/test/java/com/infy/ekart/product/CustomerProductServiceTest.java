package com.infy.ekart.product;



import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.product.dto.ProductDTO;
import com.infy.ekart.product.entity.Product;
import com.infy.ekart.product.exception.EKartProductException;
import com.infy.ekart.product.repository.ProductRepository;
import com.infy.ekart.product.service.CustomerProductService;
import com.infy.ekart.product.service.CustomerProductServiceImpl;


@SpringBootTest
@EnableAutoConfiguration
public class CustomerProductServiceTest {
	
	@Mock
	ProductRepository productRepository;
	@InjectMocks
	CustomerProductService customerProductService= new CustomerProductServiceImpl();
	
	@Test
	public void getAllProductsTestNotNull() throws EKartProductException{
		List<Product> productList = new ArrayList<>();
		Product product = new Product();
		
		productList.add(product);
		
		Iterable<Product> iterableP= productList;
		
		Mockito.when(productRepository.findAll()).thenReturn(iterableP);
		
		List<ProductDTO> pL2 = customerProductService.getAllProducts();
		
		Assertions.assertNotNull(pL2);
	}
	
	

	@Test
	public void getProductByIdNotNull() throws EKartProductException {
		Product product = new Product();
		int productId = Mockito.anyInt();
		Mockito.when(productRepository.findById(productId)).thenReturn(Optional.of(product));
		ProductDTO pDTO = customerProductService.getProductById(productId);
		Assertions.assertNotNull(pDTO);
	}
	
	@Test
	public void getProductByIdInvalid() {
		int productId = Mockito.anyInt();
		Mockito.when(productRepository.findById(productId)).thenReturn(Optional.empty());
		EKartProductException exception = 
				Assertions.assertThrows(EKartProductException.class,()->customerProductService.getProductById(productId));
		
		Assertions.assertEquals("ProductService.PRODUCT_NOT_AVAILABLE", exception.getMessage());
				
	}
	
	@Test
	public void reduceAvailableQuantityValid() throws EKartProductException {
		Product product = new Product();
		int productId = Mockito.anyInt();
		product.setProductId(productId);
		product.setAvailableQuantity(10);
		Mockito.when(productRepository.findById(productId)).thenReturn(Optional.of(product));
		customerProductService.reduceAvailableQuantity(productId, 3);
		Assertions.assertEquals(7, product.getAvailableQuantity());
	}
	
	@Test
	public void reduceAvailableQuantityInvalid() {
		int productId = Mockito.anyInt();
		Mockito.when(productRepository.findById(productId)).thenReturn(Optional.empty());
		EKartProductException exception = 
				Assertions.assertThrows(EKartProductException.class,()->customerProductService.reduceAvailableQuantity(productId, Mockito.anyInt()));
		
		Assertions.assertEquals("ProductService.PRODUCT_NOT_AVAILABLE", exception.getMessage());
	}
	
}
