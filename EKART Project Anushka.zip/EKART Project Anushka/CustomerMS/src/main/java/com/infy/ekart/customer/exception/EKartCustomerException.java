package com.infy.ekart.customer.exception;

/**
 * EKart customer exception
 * @author anush
 *
 */
public class EKartCustomerException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EKartCustomerException(String message) {
		super(message);
	}

}
