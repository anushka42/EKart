package com.infy.ekart.seller.dto;

public enum PaymentThrough {

	DEBIT_CARD, CREDIT_CARD
}
