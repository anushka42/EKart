package com.infy.ekart.seller.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.seller.dto.SellerDTO;
import com.infy.ekart.seller.entity.Seller;
import com.infy.ekart.seller.exception.EKartSellerException;
import com.infy.ekart.seller.repository.SellerRepository;

@Service(value = "sellerService")
@Transactional
public class SellerServiceImpl implements SellerService {

	@Autowired
	private SellerRepository sellerRepository;
	
	
	

	

	// This method will authenticate seller email id and password and return seller details
	@Override
	public SellerDTO authenticateSeller(String emailId, String password) throws EKartSellerException {
		SellerDTO sellerDTO = null;
	  
		//retrieving seller data from repository
		Optional<Seller> optionalSeller = sellerRepository.findById(emailId.toLowerCase());
		Seller seller = optionalSeller.orElseThrow(() -> new EKartSellerException("SellerService.SELLER_NOT_FOUND"));
		//comparing entered password with password stored in DB
		if (!password.equals(seller.getPassword()))
			throw new EKartSellerException("SellerService.INVALID_CREDENTIALS");

		sellerDTO = new SellerDTO();
		sellerDTO.setEmailId(seller.getEmailId());
		sellerDTO.setName(seller.getName());
		sellerDTO.setPhoneNumber(seller.getPhoneNumber());
		sellerDTO.setAddress(seller.getAddress());
		return sellerDTO;

	}

	//This method will register a new seller and add details to the database table
	@Override
	public String registerNewSeller(SellerDTO sellerDTO) throws EKartSellerException {
		String registeredWithEmailId = null;
		//check whether specified email id is already in use by other seller
		boolean isEmailNotAvailable = sellerRepository.findById(sellerDTO.getEmailId().toLowerCase()).isEmpty();
		//check whether specified phone no. is already in use by other seller
		boolean isPhoneNumberNotAvailable = sellerRepository.findByPhoneNumber(sellerDTO.getPhoneNumber()).isEmpty();
		if (isEmailNotAvailable) {
			if (isPhoneNumberNotAvailable) {
				Seller seller = new Seller();
				seller.setEmailId(sellerDTO.getEmailId().toLowerCase());
				seller.setName(sellerDTO.getName());
				seller.setPassword(sellerDTO.getPassword());
				seller.setPhoneNumber(sellerDTO.getPhoneNumber());
				seller.setAddress(sellerDTO.getAddress());
				sellerRepository.save(seller);
				registeredWithEmailId = seller.getEmailId();
			} else {
				throw new EKartSellerException("SellerService.PHONE_NUMBER_ALREADY_IN_USE");
			}
		} else {
			throw new EKartSellerException("SellerService.EMAIL_ID_ALREADY_IN_USE");
		}
		return registeredWithEmailId;

	}
	
	
	//this method will update the address
	@Override
	public void updateShippingAddress(String customerId , String address) throws EKartSellerException {
		//retrieving address details from repository
		Optional<Seller> optionalCustomer = sellerRepository.findById(customerId.toLowerCase());
		Seller seller = optionalCustomer.orElseThrow(() -> new EKartSellerException("CustomerService.CUSTOMER_NOT_FOUND"));
	    seller.setAddress(address);
	}

	//this method will remove address from a particular customer details
	@Override
	public void deleteShippingAddress(String customerEmailId) throws EKartSellerException {
		//retrieving customer details from repository
		Optional<Seller> optionalCustomer = sellerRepository.findById(customerEmailId.toLowerCase());
		Seller seller = optionalCustomer.orElseThrow(() -> new EKartSellerException("CustomerService.CUSTOMER_NOT_FOUND"));
		seller.setAddress(null);
	}

	@Override
	public SellerDTO getSellerByEmailId(String emailId) throws EKartSellerException {
		SellerDTO customerDTO = null;
	
		//retrieving customer data from repository
		Optional<Seller> optionalCustomer = sellerRepository.findById(emailId.toLowerCase());
		Seller seller = optionalCustomer.orElseThrow(() -> new EKartSellerException("CustomerService.CUSTOMER_NOT_FOUND"));
		//comparing entered password with password stored in DB
		

		customerDTO = new SellerDTO();
		customerDTO.setEmailId(seller.getEmailId());
		customerDTO.setName(seller.getName());
		customerDTO.setPhoneNumber(seller.getPhoneNumber());
		customerDTO.setAddress(seller.getAddress());
		return customerDTO;

	}

}
