package com.infy.ekart.seller.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infy.ekart.seller.entity.Order;

public interface OrderRepository extends CrudRepository<Order, Integer> {

List<Order> findByCustomerEmailId(String customerEmailId);

}
