package com.infy.ekart.seller.exception;

/**
 * EKart seller exception
 * @author anush
 *
 */
public class EKartSellerException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EKartSellerException(String message) {
		super(message);
	}

}
