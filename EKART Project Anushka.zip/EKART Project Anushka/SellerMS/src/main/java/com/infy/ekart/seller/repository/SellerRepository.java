package com.infy.ekart.seller.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infy.ekart.seller.entity.Seller;

public interface SellerRepository extends CrudRepository<Seller, String> {

	List<Seller> findByPhoneNumber(String phoneNumber);

}
