package com.infy.ekart.seller.service;

import java.util.List;

import com.infy.ekart.seller.dto.OrderDTO;
import com.infy.ekart.seller.dto.OrderStatus;
import com.infy.ekart.seller.dto.PaymentThrough;
import com.infy.ekart.seller.exception.EKartSellerException;

public interface OrderService {
	
	 Integer placeOrder(OrderDTO orderDTO) throws EKartSellerException;
	 OrderDTO getOrderDetails (Integer orderId) throws EKartSellerException;
	 List<OrderDTO> findOrdersBySellerEmailId(String emailId) throws EKartSellerException;
	 void updateOrderStatus( Integer orderId , OrderStatus orderStatus) throws EKartSellerException;
	 void updatePaymentThrough( Integer orderId , PaymentThrough paymentThrough) throws EKartSellerException;
	 
}
